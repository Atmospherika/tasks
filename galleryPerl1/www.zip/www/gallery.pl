#!/usr/local/bin/perl -w
use CGI;
use Fcntl; # O_EXCL, O_CREAT и O_WRONLY
use CGI qw(:standard);#для POST/GET
use CGI::Carp qw(fatalsToBrowser);#ошибки показать
use DBI; #для mysql
use File::stat;
require "include/config.pl";
print "Content-type: text/html; charset=utf-8\n\n";
require 'include/updel.pl';
require 'include/up.pl';

print <<start;
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="/css/style.css" />
<script type="text/javascript" src="/js/jquery.js"></script>
<script type="text/javascript" src="/js/script.js"></script>
<script type="text/javascript" src="/js/script2.js"></script>
<title>Галерея</title>
</head>
<body><div id='popup'></div>

<div id="main">
start

print qq~
<form  name=form id="multiform" action="gallery.pl" method="POST" enctype="multipart/form-data">
<label for="desc1">Описание:</label><input type="text" name="name" id="desc1"  value=""/> <br/>
<input type=hidden name=action value='upload' >
<label for="img1">Изображение:</label><input type="file" name="whichfile" id='img1'/><br/>
<input type='submit' value='Загрузить изображение' >
</form>	
<div id="multi-msg"></div>
~;
require 'include/showGallery.pl';
print "</div></body></html>";
