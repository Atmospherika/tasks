$ds = 'DBI:mysql:gallery:localhost';
$mysql_user = 'root';
$mysql_pass = '';
$db = DBI->connect($ds, $mysql_user, $mysql_pass) or die("Ошибка: $DBI::errstr");
#~~~~~~~~~~~~~
$db->do("SET NAMES utf8");
1;