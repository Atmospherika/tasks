if(param('delid'))
{
my $delid=param('delid');
my $res1 = $db->prepare("DELETE from `photo` WHERE `id`=\"$delid\" ");
$res1->execute();
}
if(param("desc"))
{
my $desc=param("desc");
my $id=param("id");
my $res2 = $db->prepare("UPDATE `photo` SET `desc`=\"$desc\" WHERE `id`=\"$id\" ");
$res2->execute();
}
1;