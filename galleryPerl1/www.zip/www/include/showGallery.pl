my $res = $db->prepare("SELECT * FROM `photo`");
$res->execute();	
my $registreted = $res->rows();
my @rows1;
if($registreted > 0)#если фото есть
	{
		while(my @row1 = $res->fetchrow_array())#заполняем массив 
		{
		push(@rows1, [@row1]);
		}
	}
print "<div id='one'><div id='loader'></div><img src='/images/cancel.png' id='close' alt='close' onclick='delPhoto()'/><div id='big'>";
	if($registreted > 0)#если фото есть
	{
		if(param("src"))#если аякс передал фотографию
		{
		my $src=param("src");
		print "<img id='image1' src=\"$src\"/>";
		}
		else #если никаких действий с аяксом совершено не было
		{
		print "<img id='image1' src='".$rows1[0][1]."'/>";
		}
	}
	
print "</div>";
	if($registreted > 0)
	{	if(param("desc"))#если аякс передал описание
		{
		my $desc=param("desc");
		print "<input type='hidden' id='id' value=\"id\"><input type='text' id='desc' value=\"$desc\" onchange='editContent()' />";
		}
		else#если не передал(первое обращение к галерии)
		{
		print "<input type='hidden' id='id' value=\"$rows1[0][0]\"><input type='text' id='desc' value=\"$rows1[0][2]\" onchange='editContent()' />";
		}
	}
	
print <<main;
</div>
<div id="many">
main
my $j=0;
	if($registreted > 0)
	{
		while($rows1[$j])
		{
		print "<img src='".$rows1[$j][1]."' class='photos' onclick='loadphoto(\"$rows1[$j][0]\",\"$rows1[$j][1]\",\"$rows1[$j][2]\")' />";
		$j++;
		}
	}

print "</div>";
1;