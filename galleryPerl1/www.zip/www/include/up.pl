$UploadPath = 'Z:/home/gallery/www/images/';
$MaxSize = '20000'; # For no max size, leave blank. Max size of KBYTES.

#print "Content-type: text/html\n\n";
$File2 = param('whichfile');
$Action = param('action');
$descr=param('name');
if ($Action eq 'upload') 
{
&Upload;
	if($File2)
	{
	my $new = $db->prepare("INSERT INTO `photo`(`src`,`desc`) VALUES(\"/images/$File2\", \"$descr\")");
	$new->execute();
	}
}

sub Upload 
{#подпрограмма загрузки
#$File2 = param('whichfile');
$NewFile = "$UploadPath/$File2";
$MaxSizeBytes =1024 * $MaxSize;
#$ok = 1;

	if (!-e "$NewFile") 
	{#если такой файл не существует
	open(OUTFILE, ">$NewFile") or &error('cant create new file of this name! $!');
	binmode OUTFILE;
		while ($bytesread=read($File2,$buffer,1024)) 
		{
		print OUTFILE $buffer;
		}
	close (OUTFILE);

	$inode = stat($NewFile);
	$Size = $inode->size;

		if ($Size > $MaxSizeBytes) 
		{
		# If it is too big, remove it and &error out
		unlink "$NewFile" or &error("cant unlink $NewFile, too big; $!");
		&error('Your file was too big!');
		}
	}

}


sub error 
{
my $err = shift;
print qq~
An error occured: <B>$err</B>~;
exit;
}
1;