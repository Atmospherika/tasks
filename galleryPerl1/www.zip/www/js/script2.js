$(document).ready(function()
{

$("#multiform").submit(function(e)
{
	$("#multi-msg").html("<img src='/images/ajax-loader-343.gif'/>");

	var formObj = $(this);
	var formURL = formObj.attr("action");

if(window.FormData !== undefined) 

	{
	
		var formData = new FormData(this);
		$.ajax({
        	url: formURL,
	        type: 'POST',
			data:  formData,
			mimeType:"multipart/form-data",
			contentType: false,
    	    cache: false,
        	processData:false,
			success: function(msg)
		    {
					$("body").html(msg);
		    }
	        
	   });
        e.preventDefault();//не дает сработать сабмиту по умолчанию
        e.unbind();
   }

});



});