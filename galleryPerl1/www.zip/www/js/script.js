function loadphoto(id,src,desc)
{

$('#big').empty();
$('#desc').empty();
$('#big').attr('style', 'display:none;');
$('#desc').attr('style', 'display:none;');
$("#desc").val(desc);
$("#desc").fadeIn(500);
$("#big").append("<img id='image1' src="+src+" />");
$("#big").fadeIn(500);
$("#id").val(id);
}

function editContent()
{
var desc=document.getElementById("desc").value;
var id=document.getElementById("id").value;
var src=document.getElementById("image1").getAttribute('src');// 123

//alert(id);
$.ajax({
		
		dataType:"html",
		type:"POST",
		async:true,
	
		data:({
			'id':id,
			'desc':desc,
			'src':src
		}),
		beforeSend:function()
		{
		$('#popup').fadeIn();
		$('#loader').fadeIn();
		},
		success:function(msg)
			{//alert('close');
			
			$('body').html(msg);
			
			}
	});

}
function delPhoto()
{
var id=document.getElementById("id").value;
//alert(id);
$.ajax({
		
		dataType:"html",
		type:"POST",
		async:true,
	
		data:({
			'delid':id
		}),
		beforeSend:function()
		{
		$('#popup').fadeIn();
		$('#loader').fadeIn();
		},
		success:function(msg)
			{
			//alert('yes');
			$('body').html(msg);
			}
	});
}


